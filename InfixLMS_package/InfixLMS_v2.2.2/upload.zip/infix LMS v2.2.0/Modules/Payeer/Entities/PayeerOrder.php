<?php

namespace Modules\Payeer\Entities;

use Illuminate\Database\Eloquent\Model;

class PayeerOrder extends Model
{
    protected $fillable = [];
}
