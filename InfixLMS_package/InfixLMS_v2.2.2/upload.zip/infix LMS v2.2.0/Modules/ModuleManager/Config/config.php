<?php

return [
    'name' => 'ModuleManager'
];
