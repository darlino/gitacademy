<?php

return [
    'name' => 'ImageGallery'
];
