<?php

return [
    'name' => 'Paytm'
];
