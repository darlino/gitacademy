<li>
    <a class="" href="{{route('blogs.index')}}" aria-expanded="false">
        <div class="nav_icon_small">
            <i class="fas fa-blog"></i>
        </div>
        <div class="nav_title">
            <span>{{__('common.Blogs')}}</span>
        </div>
    </a>
</li>
