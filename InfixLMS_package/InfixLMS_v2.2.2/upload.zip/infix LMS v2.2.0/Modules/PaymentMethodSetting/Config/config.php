<?php

return [
    'name' => 'PaymentMethodSetting'
];
