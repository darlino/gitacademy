<?php

namespace Modules\Appearance\Entities;

use Illuminate\Database\Eloquent\Model;

class Theme extends Model
{

    protected $guarded = ['id'];

}
