<?php

return [
    'name' => 'Appearance'
];
