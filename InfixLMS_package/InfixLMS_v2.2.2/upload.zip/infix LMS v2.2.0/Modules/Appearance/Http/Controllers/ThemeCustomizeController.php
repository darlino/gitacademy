<?php

namespace Modules\Appearance\Http\Controllers;

use Brian2694\Toastr\Facades\Toastr;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Modules\Appearance\Entities\Theme;
use Modules\Appearance\Entities\ThemeCustomize;

class ThemeCustomizeController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function index()
    {
        try {
            $themes = ThemeCustomize::all();

            return view('appearance::customize.index', compact('themes'));
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $default = ThemeCustomize::first();
        $themes = Theme::all();
        return view('appearance::customize.create', compact('themes', 'default'));

    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|max:191',
            'theme' => 'required|max:191',
            'is_default' => 'sometimes|required|boolean',
            's_color' => 'required|string|max:20',
            'p_color' => 'required|string|max:20',
        ]);

        if ($request->is_default) {
            ThemeCustomize::where('is_default', 1)->where('theme_id', $request->theme)->update(['is_default' => 0]);
        }

        $theme = new ThemeCustomize();
        $theme->name = $request->title;
        $theme->theme_id = $request->theme;
        $theme->secondary_color = $request->s_color;
        $theme->primary_color = $request->p_color;

        $theme->is_default = $request->is_default ? 1 : 0;
        $theme->created_by = Auth::id();
        $theme->save();
        $this->clearSesson();


        Toastr::success(__('setting.New Theme Created Successful'), __('common.Success'));
        return redirect()->to(route('appearance.themes-customize.index'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('appearance::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $editData = ThemeCustomize::findOrFail($id);
        $themes = Theme::all();
        return view('appearance::customize.edit', compact('themes', 'editData'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|max:191',
            'theme' => 'required|max:191',
            's_color' => 'required|string|max:20',
            'p_color' => 'required|string|max:20',
        ]);


        $theme = ThemeCustomize::findOrFail($id);
        $theme->name = $request->title;
        $theme->theme_id = $request->theme;
        $theme->secondary_color = $request->s_color;
        $theme->primary_color = $request->p_color;
        $theme->save();

        $this->clearSesson();

        Toastr::success(__('setting.Theme Update Successfully'), __('common.Success'));
        return redirect()->to(route('appearance.themes-customize.index'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $theme = ThemeCustomize::findOrFail($id);

        if ($theme->id == 1) {
            Toastr::error(__('setting.You can not permitted to delete system theme'), __('common.Operation failed'));
            return redirect()->back();
        }

        if ($theme->is_default) {
            Theme::find(1)->update(['is_default' => 1]);
        }
        $this->clearSesson();

        $theme->delete();
        Toastr::success(__('setting.Theme Deleted Successful'), __('common.Success'));
        return redirect()->back();
    }


    public function copy($id)
    {

        $theme = ThemeCustomize::findOrFail($id);

        $newTheme = new ThemeCustomize();
        $newTheme->name = __('setting.Clone of') . ' ' . $theme->name;
        $newTheme->created_at = Carbon::now();
        $newTheme->primary_color = $theme->primary_color;
        $newTheme->secondary_color = $theme->secondary_color;
        $newTheme->is_default = false;
        $newTheme->created_by = Auth::id();
        $newTheme->save();
        $this->clearSesson();

        Toastr::success(__('setting.Theme Cloned Successful'), __('common.Success'));
        return redirect()->back();

    }

    public function default($id)
    {
        $theme = ThemeCustomize::findOrFail($id);


        ThemeCustomize::where('is_default', 1)->where('theme_id', $theme->theme_id)->update(['is_default' => 0]);
        $theme->is_default = 1;
        $theme->save();
        $this->clearSesson();
        Toastr::success(__('setting.Theme Set Default Successful'), __('common.Success'));
        return redirect()->back();

    }

    public function clearSesson()
    {
        Session::forget('color_theme');

    }
}
