<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


//Route::middleware('auth:api')->get('/appearance', function (Request $request) {
//    return $request->user();
//});
