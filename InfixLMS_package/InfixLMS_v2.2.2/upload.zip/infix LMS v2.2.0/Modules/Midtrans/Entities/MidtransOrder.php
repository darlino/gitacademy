<?php

namespace Modules\Midtrans\Entities;

use Illuminate\Database\Eloquent\Model;

class MidtransOrder extends Model
{
    protected $fillable = [];
}
