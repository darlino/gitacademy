<li class="">
    <a href="{{ route('backup.index') }}" class="" aria-expanded="false">
        <div class="nav_icon_small">
            <span class="fas fa-file-download"></span>
        </div>
        <div class="nav_title">
            <span>{{ __('common.Backup') }}</span>
        </div>
    </a>
</li>
