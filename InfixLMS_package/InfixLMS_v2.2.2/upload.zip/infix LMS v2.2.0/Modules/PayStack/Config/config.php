<?php

return [
    'name' => 'PayStack'
];
