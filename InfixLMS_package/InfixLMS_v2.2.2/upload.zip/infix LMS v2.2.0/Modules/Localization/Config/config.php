<?php

return [
    'name' => 'Localization'
];
