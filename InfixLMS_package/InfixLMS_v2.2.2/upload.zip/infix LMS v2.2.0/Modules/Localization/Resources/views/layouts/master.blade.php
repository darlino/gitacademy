@include('backend.partials.header')

@yield('mainContent')

@include('backend.partials.footer')
