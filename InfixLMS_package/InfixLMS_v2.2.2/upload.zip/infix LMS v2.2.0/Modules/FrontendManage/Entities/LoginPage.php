<?php

namespace Modules\FrontendManage\Entities;

use Illuminate\Database\Eloquent\Model;

class LoginPage extends Model
{
    protected $fillable = [];
}
