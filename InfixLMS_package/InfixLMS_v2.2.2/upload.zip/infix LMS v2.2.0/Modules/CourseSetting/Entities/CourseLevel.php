<?php

namespace Modules\CourseSetting\Entities;

use Illuminate\Database\Eloquent\Model;

class CourseLevel extends Model
{
    protected $fillable = [];
}
