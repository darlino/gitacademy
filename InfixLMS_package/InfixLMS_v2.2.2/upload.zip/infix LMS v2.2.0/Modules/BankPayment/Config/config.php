<?php

return [
    'name' => 'BankPayment'
];
