<?php

namespace Modules\Newsletter\Entities;

use Illuminate\Database\Eloquent\Model;

class NewsletterSetting extends Model
{
    protected $fillable = [];
}
