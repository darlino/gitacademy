<?php

return [
    'name' => 'OfflinePayment'
];
