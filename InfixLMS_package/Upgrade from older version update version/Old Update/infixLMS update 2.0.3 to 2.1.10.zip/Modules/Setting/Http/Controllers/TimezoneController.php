<?php

namespace Modules\Setting\Http\Controllers;

use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

class TimezoneController extends Controller
{
    public function index(Request $request)
    {
        if ($request->code) {
            $code_search = $request->code;
        } else {
            $code_search = '';
        }
        if ($request->timezone) {
            $timezone_search = $request->timezone;
        } else {
            $timezone_search = '';
        }


        $query = DB::table('time_zones');


        if ($request->code) {
            $query->where('time_zones.code', 'LIKE', '%' . $request->code . '%');
        }

        if ($request->timezone) {
            $query->where('time_zones.time_zone', 'LIKE', '%' . $request->timezone . '%');
        }

        $timezones = $query->get();

        return view('setting::timezone.index', [
            "timezones" => $timezones,
            "code_search" => $code_search,
            "timezone_search" => $timezone_search,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        try {
            DB::table('time_zones')->insert([
                'code' => $request->code,
                'time_zone' => $request->timezone,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            Toastr::success(trans('common.Operation successful'), trans('common.Success'));
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error(trans('common.Operation failed'), trans('common.Failed'));
            return redirect()->back();
        }
    }


    public function update(Request $request, $id)
    {
        try {
            $timezone = DB::table('time_zones')
                ->where('id', $id)
                ->update([
                    'code' => $request->code,
                    'time_zone' => $request->time_zone,
                    'updated_at' => now(),
                ]);
            Toastr::success(trans('common.Operation successful'), trans('common.Success'));
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error(trans('common.Operation failed'), trans('common.Failed'));
            return redirect()->back();
        }
    }

    public function destroy($id)
    {
        try {
            DB::table('time_zones')->where('id', $id)->delete();
            Toastr::success(__('setting.Timezone has been deleted Successfully'), trans('common.Success'));
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error(trans('common.Operation failed'), trans('common.Failed'));
            return redirect()->back();
        }
    }

    public function edit_modal(Request $request)
    {
        try {
            $timezone = DB::table('time_zones')->where('id', $request->id)->first();
            return view('setting::timezone.edit_modal', [
                "timezone" => $timezone,
            ]);
        } catch (\Exception $e) {
            Toastr::error(trans('common.Operation failed'), trans('common.Failed'));
            return false;
        }
    }
}
