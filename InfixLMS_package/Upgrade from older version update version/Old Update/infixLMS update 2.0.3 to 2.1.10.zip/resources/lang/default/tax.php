<?php

return [
    'TAX' => 'TAX',
    'TAX Setting' => 'TAX Setting',
    'Percentage' => 'Percentage',
    'Apply TAX' => 'Apply TAX'
];
