<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Modules\CourseSetting\Entities\Course;

class EdumeFrontendThemeController extends Controller
{
    public function getCourseByCategory($category_id)
    {
        $courses = Course::where('category_id', $category_id)->where('status', 1)
            ->where('type', 1)->latest()->get();
        $result = '  <div class="lms_course_grid">';
        foreach ($courses as $key => $course) {
            $image = file_exists($course->thumbnail) ? asset($course->thumbnail) : asset('public/\uploads/course_sample.png');
            if ($course->discount_price != null) {
                $price = getPriceFormat($course->discount_price);
            } else {
                $price = getPriceFormat($course->price);
            }
            if (strlen($course->about) > 100) {
                $details = substr($course->about, 0, 100) . '...';
            } else {
                $details = substr($course->about, 0, 100);
            }

            $main_stars = getTotalRating($course->id);

            $stars = intval(getTotalRating($course->id));
            $star = '';
            for ($i = 0; $i < $stars; $i++) {
                $star .= ' <i class="fas fa-star" ></i >';
            }
            if ($main_stars > $stars) {
                $star .= '<i class="fas fa-star-half" ></i >';
            }
            if ($main_stars == 0) {
                for ($i = 0; $i < 5; $i++) {
                    $star .= '<i class="far fa-star" ></i >';
                }
            }

            $result .= '
                                        <!-- lms_course_wizerd  -->
                                        <div class="lms_course_wizerd">
                                            <div class="thumb">
                                                <img src="' . $image . '"  alt="">
                                                <div class="tag_btns">
                                                    <span>' . $course->courseLevel->title . '</span>
                                                    <span>' . $price . '</span>
                                                </div>
                                            </div>
                                            <div class="lms_course_content">
                                                <a href="' . route('courseDetailsView', [@$course->id, @$course->slug]) . '">
                                                    <h4>' . $course->title . '</h4>
                                                </a>
                                                <p>
                                                ' . $details . '
                                                </p>
                                                <div class="lms_course_bottom">
                                                    <div class="author_thumb">
                                                        <a href="' . route('courseDetailsView', [@$course->id, @$course->slug]) . '">
                                                            <img
                                                                src="' . getInstructorImage(@$course->user->image) . '"
                                                                alt="">
                                                        </a>
                                                        <div class="star_icon">
                                                            <img
                                                                src="' . asset('public/frontend / edume') . 'img/lms_course/star.png"
                                                                alt="">
                                                        </div>
                                                    </div>
                                                    <div class="author_info">
                                                        <a href="instractor-details.php"><h5>' . $course->user->name . ' </h5 ></a >
                                                        <p > ' . $course->user->headline . ' </p >
                                                    </div >
                                                </div >
                                            </div >
                                            <!--course_hover  -->
                                            <div class="lms_course_hover" >
                                             <a href="' . route('courseDetailsView', [@$course->id, @$course->slug]) . '">
                                                       <h4>' . $course->title . '</h4>
                                                </a >
                                                <div class="course_tag_seller" >
                                        <span class="best_selletTag" >
             <span>' . $course->courseLevel->title . '</span>
                                        </span >
                                                    <div class="rating_star" >
                                                        <div class="stars" >
                                                           ' . $star . '
                                                        </div >
                                                        <p > ( ' . count($course->reviews) . ' ' . trans("frontend.Ratings") . ')</p >
                                                    </div >
                                                </div >
                                                <p class="course_duration" >
                                                 ' . count($course->lessons) . '
                                         ' . trans(('frontend.Lessons')) . '
                                                  <span lass="dot_devide" >•</span >
                                                     ' . trans(('frontend.Duration')) . '
                                                      ' . $course->duration . '

                                                   </p >
                                                <p class="course_info" >

                                                ' . $details . '
</p >

                                                <div class="check_lists" >
                                                    <div class="single_checklist" >
                                                        <div class="check_icon" >
                                                            <img
                                                                src = "' . asset('public/frontend / edume') . '/img/lms_course/check.png"
                                                                alt = "" >
                                                        </div >
                                                        <p > Skilled and experienced coaches .</p >
                                                    </div >
                                                    <div class="single_checklist" >
                                                        <div class="check_icon" >
                                                            <img
                                                             src = "' . asset('public/frontend / edume') . '/img/lms_course/check.png"
                                                                alt = "" >
                                                        </div >
                                                        <p > Craft a portfolio of websites to apply for
                junior developer jobs .</p >
                                                    </div >
                                                </div >
                                                <div class="lms_course_bottom" >
                                                    <div class="author_thumb" >
                                                        <a href = "instractor-details.php" >
                                                            <img
                                                                src = "' . asset('public/frontend / edume') . '/img/lms_course/author.png"
                                                                alt = "" >
                                                        </a >
                                                        <div class="star_icon" >
                                                            <img
                                                                src = "' . asset('public/frontend / edume') . '/img/lms_course/star.png"
                                                                alt = "" >
                                                        </div >
                                                    </div >
                                                    <div class="author_info" >
                                                        <a href = "instractor-details.php" ><h5 > Emma Watson </h5 ></a >
                                                        <p > UI / UX Designer </p >
                                                    </div >
                                                </div >
                                                <div class="lms_course_btns" >
                                                    <a href = "#" class="theme_btn  cart_store text-nowrap" > Add to
                                                        Cart </a >
                                                    <a href = "#" class="theme_line_btn text-nowrap" > Add to Wishlist </a >
                                                </div >
                                            </div >
                                        </div >

            ';
        }

        $result .= '  </div > ';

        return $result;
    }
}
