@extends('backend.master')

@php
    $table_name='courses';
@endphp
@section('table'){{$table_name}}@stop
@section('mainContent')
    <section class="sms-breadcrumb mb-40 white-box">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <h1>{{__('courses.Courses')}}</h1>
                <div class="bc-pages">
                    <a href="{{route('dashboard')}}">{{__('common.Dashboard')}}</a>
                    <a href="#">{{__('courses.Courses')}}</a>
                    <a href="#">{{__('courses.Courses List')}}</a>
                </div>
            </div>
        </div>
    </section>
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">

            <div class="row justify-content-center mt-50">
                <div class="col-lg-12">
                    <div class="white_box mb_30">
                        <div class="white_box_tittle list_header">
                            <h4>{{__('courses.Advanced Filter')}} </h4>
                        </div>
                        <form action="{{route('courseSortBy')}}" method="POST">
                            @csrf
                            <div class="row">

                                <div class="col-lg-3 mt-30">

                                    <label class="primary_input_label" for="category">{{__('courses.Category')}}</label>
                                    <select class="primary_select" name="category" id="category">
                                        <option data-display="{{__('common.Select')}} {{__('courses.Category')}}"
                                                value="">{{__('common.Select')}} {{__('courses.Category')}}</option>
                                        @foreach($categories as $category)
                                            <option
                                                value="{{$category->id}}" {{isset($category_search)?$category_search==$category->id?'selected':'':''}}>{{@$category->name}} </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-lg-3 mt-30">

                                    <label class="primary_input_label" for="type">{{__('courses.Type')}}</label>
                                    <select class="primary_select" name="type" id="type">
                                        <option data-display="{{__('common.Select')}} {{__('courses.Type')}}"
                                                value="">{{__('common.Select')}} {{__('courses.Type')}}</option>
                                        <option
                                            value="1" {{isset($category_type)?$category_type==1?'selected':'':''}}>{{__('courses.Course')}}</option>
                                        <option
                                            value="2" {{isset($category_type)?$category_type==2?'selected':'':''}}>{{__('quiz.Quiz')}}</option>
                                    </select>

                                </div>
                                <div class="col-lg-3 mt-30">

                                    <label class="primary_input_label"
                                           for="instructor">{{__('courses.Instructor')}}</label>
                                    <select class="primary_select" name="instructor" id="instructor">
                                        <option data-display="{{__('common.Select')}} {{__('courses.Instructor')}}"
                                                value="">{{__('common.Select')}} {{__('courses.Instructor')}}</option>
                                        @foreach($instructors as $instructor)
                                            <option
                                                value="{{$instructor->id}}" {{isset($category_instructor)?$category_instructor==$instructor->id?'selected':'':''}}>{{@$instructor->name}} </option>
                                        @endforeach
                                    </select>

                                </div>
                                <div class="col-lg-3 mt-30 d-none">
                                    <label class="primary_input_label" for="course">{{__('courses.Statistics')}}</label>
                                    <select class="primary_select" name="course" id="course">
                                        <option data-display="{{__('common.Select')}} {{__('courses.Statistics')}}"
                                                value="">{{__('common.Select')}} {{__('courses.Statistics')}}</option>
                                        <option value="statistics">{{__('courses.Statistics')}}</option>
                                        <option value="topSell">Top Sells</option>
                                        <option value="mostReview">Most Review</option>
                                        <option value="mostComment">Most Comment</option>
                                        <option value="topReview">Top Review</option>
                                    </select>

                                </div>
                                <div class="col-lg-3 mt-30">

                                    <label class="primary_input_label" for="status">{{__('common.Status')}}</label>
                                    <select class="primary_select" name="search_status" id="status">
                                        <option data-display="{{__('common.Select')}} {{__('common.Status')}}"
                                                value="">{{__('common.Select')}} {{__('common.Status')}}</option>
                                        <option
                                            value="1" {{isset($category_status)?$category_status=="1"?'selected':'':''}}>{{__('courses.Active')}} </option>
                                        <option
                                            value="0" {{isset($category_status)?$category_status=="0"?'selected':'':''}}>{{__('courses.Pending')}} </option>
                                    </select>

                                </div>


                                <div class="col-12 mt-20">
                                    <div class="search_course_btn text-right">
                                        <button type="submit"
                                                class="primary-btn radius_30px mr-10 fix-gr-bg">{{__('courses.Filter')}} </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-12">
                    <div class="box_header common_table_header">
                        <div class="main-title d-md-flex">
                            <h3 class="mb-0 mr-30 mb_xs_15px mb_sm_20px">{{$title??""}} {{__('courses.Course')}}
                                /{{__('quiz.Quiz')}} {{__('courses.List')}}</h3>
                            @if (permissionCheck('course.store'))
                                <ul class="d-flex">
                                    <li><a class="primary-btn radius_30px mr-10 fix-gr-bg" data-toggle="modal"
                                           id="add_course_btn"
                                           data-target="#add_course" href="#"><i
                                                class="ti-plus"></i>{{__('common.Add')}} {{__('courses.Course')}}
                                            /{{__('quiz.Quiz')}}</a></li>
                                </ul>
                            @endif
                        </div>

                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="QA_section QA_section_heading_custom check_box_table">
                        <div class="QA_table">
                            <!-- table-responsive -->
                            <div class="">
                                <table id="lms_table" class="table classList">
                                    <thead>
                                    <tr>
                                        <th scope="col"> {{__('coupons.Type')}}</th>
                                        <th scope="col">{{__('courses.Course')}}
                                            /{{__('quiz.Quiz')}} {{__('coupons.Title')}}</th>
                                        <th scope="col">{{__('quiz.Category')}}</th>
                                        <th scope="col">{{__('quiz.Quiz')}}</th>
                                        <th scope="col">{{__('courses.Instructor')}}</th>
                                        <th scope="col">{{__('common.Status')}}</th>
                                        <th scope="col">{{__('courses.Lesson')}}</th>
                                        <th scope="col">{{__('courses.Enrolled')}}</th>

                                        <th scope="col">{{__('courses.Price')}}</th>
                                        <th scope="col">{{__('common.Action')}}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {{--             @foreach (@$courses as $key => $course)
                                                     <tr>
                                                         <td class="">
                                                             <span class="m-2">
                                                                 @if(@$course->type==1)
                                                                     {{__('courses.Course')}}

                                                                 @else
                                                                     {{__('quiz.Quiz')}}
                                                                 @endif

                                                             </span>
                                                         </td>
                                                         <td>{{@$course->title}}</td>
                                                         <td>{{@$course->category->name}}
                                                             /<span> {{@$course->subCategory->name}}</span>
                                                         </td>
                                                         <td>{{@$course->quiz->title}} </td>
                                                         <td>{{@$course->user->name}} </td>
                                                         <td>
                                                             <label class="switch_toggle" for="active_checkbox{{@$course->id }}">
                                                                 <input type="checkbox" class="status_enable_disable"
                                                                        id="active_checkbox{{@$course->id }}"
                                                                        @if (@$course->status == 1) checked
                                                                        @endif value="{{@$course->id }}">
                                                                 <i class="slider round"></i>
                                                             </label>

                                                         </td>
                                                         <td>{{@$course->lessons->count()}}</td>
                                                         <td>{{@$course->enrolls->count()}}</td>

                                                         <td>
                                                             @if (@$course->discount_price!=null)
                                                                 <span>{{@$getsmSetting->symbol}} {{@$course->discount_price * $getsmSetting->conversion_rate}} </span>
                                                             @else
                                                                 <span>{{@$getsmSetting->symbol}} {{@$course->price * $getsmSetting->conversion_rate}} </span>

                                                             @endif
                                                             @if (@$course->discount_price!=null)
                                                                 <br>
                                                                 <span
                                                                     style="text-decoration: line-through"> {{@$getsmSetting->symbol}} {{@$course->price * $getsmSetting->conversion_rate}} </span>
                                                             @endif

                                                         </td>


                                                         <td>
                                                             <div class="dropdown CRM_dropdown">
                                                                 <button class="btn btn-secondary dropdown-toggle" type="button"
                                                                         id="dropdownMenu2" data-toggle="dropdown"
                                                                         aria-haspopup="true"
                                                                         aria-expanded="false">
                                                                     {{__('common.Action')}}
                                                                 </button>
                                                                 <div class="dropdown-menu dropdown-menu-right"
                                                                      aria-labelledby="dropdownMenu2">
                                                                     <a target="_blank"
                                                                        href="{{courseDetailsUrl(@$course->id,$course->type,$course->slug)}}"
                                                                        class="dropdown-item"
                                                                     >{{__('courses.Frontend View')}}</a>

                                                                     @if (permissionCheck('course.details'))
                                                                         <a href="{{route('courseDetails',[@$course->id])}}"
                                                                            class="dropdown-item"
                                                                         >{{__('courses.Add Lesson')}}</a>

                                                                     @endif

                                                                     @if (permissionCheck('course.edit'))
                                                                         <button data-toggle="modal"
                                                                                 data-target="#editCourse{{@$course->id}}"
                                                                                 class="dropdown-item"
                                                                                 type="button">{{__('common.Edit')}}</button>
                                                                     @endif

                                                                     @if (permissionCheck('course.view'))
                                                                         <a href="{{courseDetailsUrl(@$course->id,@$course->type,@$course->slug)}}"
                                                                            class="dropdown-item"
                                                                         >{{__('common.View')}}</a>
                                                                     @endif
                                                                     @if (permissionCheck('course.delete '))
                                                                         <a onclick="confirm_modal('{{route('course.delete', $course->id)}}');"
                                                                            class="dropdown-item edit_brand">{{__('common.Delete')}}</a>

                                                                     @endif


                                                                 </div>
                                                             </div>

                                                         </td>


                                                     </tr>




                                                 @endforeach--}}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- @dd(Auth::user()) --}}
                <div class="modal fade admin-query" id="add_course">
                    <div class="modal-dialog modal_1000px modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">{{__('common.Add New')}} {{__('quiz.Topic')}}</h4>
                                <button type="button" class="close " data-dismiss="modal">
                                    <i class="ti-close "></i>
                                </button>
                            </div>
                            <input type="hidden" id="url" value="{{url('/')}}">
                            <div class="modal-body">
                                <form action="{{route('AdminSaveCourse')}}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">
                                        <div class="col-xl-6 ">
                                            <div class="primary_input mb-25">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <label class="primary_input_label"
                                                               for=""> {{__('courses.Type')}} * </label>
                                                    </div>
                                                    <div class="col-md-6 ">

                                                        <input type="radio" class="common-radio" id="type1"
                                                               name="type"
                                                               value="1"
                                                               @if(empty(old('type')))checked @else {{old('type')==1?"checked":""}} @endif>
                                                        <label for="type1">{{__('courses.Course')}}</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input type="radio" class="common-radio" id="type2"
                                                               name="type"
                                                               value="2" {{old('type')==2?"checked":""}}>
                                                        <label for="type2">{{__('quiz.Quiz')}}</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 " id="dripCheck">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label mt-1"
                                                       for=""> {{__('common.Drip Content')}}</label>
                                                <div class="row">
                                                    <div class="col-md-6">

                                                        <input type="radio" class="common-radio drip0"
                                                               id="drip0" name="drip"
                                                               value="0" checked>
                                                        <label
                                                            for="drip0">{{__('common.No')}}</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input type="radio" class="common-radio drip1"
                                                               id="drip1" name="drip"
                                                               value="1">
                                                        <label
                                                            for="drip1">{{__('common.Yes')}}</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('quiz.Topic')}} {{__('common.Title')}} *</label>
                                                <input class="primary_input_field" name="title" placeholder="-"
                                                       id="addTitle"
                                                       type="text" {{$errors->has('title') ? 'autofocus' : ''}}
                                                       value="{{old('title')}}">
                                            </div>
                                        </div>


                                    </div>

                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Course')}} {{__('courses.Requirements')}}
                                                </label>
                                                <textarea class="lms_summernote" name="requirements"
                                                          id="addRequirements" cols="30"
                                                          rows="10">{{old('requirements')}}</textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Course')}} {{__('courses.Description')}}
                                                </label>
                                                <textarea class="lms_summernote" name="about" id="addAbout" cols="30"
                                                          rows="10">{{old('about')}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Course')}} {{__('courses.Outcomes')}}
                                                </label>
                                                <textarea class="lms_summernote" name="outcomes" id="addOutcomes"
                                                          cols="30"
                                                          rows="10">{{old('outcomes')}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-6 courseBox mb_30">
                                            <select class="primary_select category_id" name="category"
                                                    id="category_id" {{$errors->has('category') ? 'autofocus' : ''}}>
                                                <option data-display="{{__('common.Select')}} {{__('quiz.Category')}} *"
                                                        value="">{{__('common.Select')}} {{__('quiz.Category')}} </option>
                                                @foreach($categories as $category)
                                                    <option value="{{$category->id}}">{{@$category->name}} </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-xl-6 courseBox" id="subCategoryDiv">
                                            <select class="primary_select" name="sub_category"
                                                    id="subcategory_id" {{$errors->has('sub_category') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{ __('common.Select') }} {{ __('courses.Sub Category') }}  "
                                                    value="">{{ __('common.Select') }} {{ __('courses.Sub Category') }}
                                                </option>
                                            </select>
                                        </div>

                                        <div class="col-xl-6 mt-30 quizBox" style="display: none">
                                            <select class="primary_select" name="quiz"
                                                    id="quiz_id" {{$errors->has('quiz') ? 'autofocus' : ''}}>
                                                <option data-display="{{__('common.Select')}} {{__('quiz.Quiz')}} *"
                                                        value="">{{__('common.Select')}} {{__('quiz.Quiz')}} </option>
                                                @foreach($quizzes as $quiz)
                                                    <option value="{{$quiz->id}}">{{@$quiz->title}} </option>
                                                @endforeach
                                            </select>
                                        </div>


                                        <div class="col-xl-4 makeResize mt-30">
                                            <select class="primary_select" name="level">
                                                <option
                                                    data-display="{{ __('common.Select') }} {{ __('courses.Level') }} *"
                                                    value="">{{ __('common.Select') }} {{ __('courses.Level') }}
                                                </option>
                                                @foreach($levels as $level)
                                                    <option
                                                        value="{{$level->id}}" {{old('level')==$level->id?"selected":""}} >{{$level->title}}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                        <div class="col-xl-4 mt-30 makeResize" id="">
                                            <select class="primary_select mb-25" name="language"
                                                    id="" {{$errors->has('language') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{ __('common.Select') }} {{ __('common.Language') }} *"
                                                    value="">{{ __('common.Select') }} {{ __('common.Language') }}</option>
                                                @foreach ($languages as $language)
                                                    <option
                                                        value="{{$language->id}}" {{old('language')==$language->id?"selected":""}}>{{$language->native}}</option>

                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-xl-4 makeResize" id="durationBox">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{ __('common.Duration') }} *</label>
                                                <input class="primary_input_field" name="duration" placeholder="-"
                                                       id="addDuration"
                                                       type="text"
                                                       value="{{old('duration')}}" {{$errors->has('duration') ? 'autofocus' : ''}}>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row d-none">
                                        <div class="col-lg-6">
                                            <div class="checkbox_wrap d-flex align-items-center">
                                                <label for="course_1" class="switch_toggle mr-2">
                                                    <input type="checkbox" id="course_1">
                                                    <i class="slider round"></i>
                                                </label>
                                                <label
                                                    class="mb-0">{{ __('courses.This course is a top course') }}</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-20">
                                        <div class="col-lg-6">
                                            <div class="checkbox_wrap d-flex align-items-center mt-40">
                                                <label for="course_2" class="switch_toggle mr-2">
                                                    <input type="checkbox" id="course_2" value="1" name="is_free">
                                                    <i class="slider round"></i>
                                                </label>
                                                <label
                                                    class="mb-0">{{ __('courses.This course is a free course') }}</label>
                                            </div>
                                        </div>
                                        <div class="col-xl-6" id="price_div">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{ __('courses.Price') }}</label>
                                                <input class="primary_input_field" name="price" placeholder="-"
                                                       id="addPrice"
                                                       type="text" value="{{old('price')}}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-20" id="discountDiv">
                                        <div class="col-lg-6">
                                            <div class="checkbox_wrap d-flex align-items-center mt-40">
                                                <label for="course_3" class="switch_toggle mr-2">
                                                    <input type="checkbox" id="course_3" value="1" name="is_discount">
                                                    <i class="slider round"></i>
                                                </label>
                                                <label
                                                    class="mb-0">{{ __('courses.This course has discounted price') }}</label>
                                            </div>
                                        </div>
                                        <div class="col-xl-4" id="discount_price_div" style="display: none">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{ __('courses.Discount') }} {{ __('courses.Price') }}</label>
                                                <input class="primary_input_field" name="discount_price" placeholder="-"
                                                       id="addDiscount"
                                                       type="text" value="{{old('discount_price')}}">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mt-20 videoOption">
                                        <div class="col-xl-4 mt-25">
                                            <select class="primary_select category_id " name="host"
                                                    id="">
                                                <option
                                                    data-display="{{__('courses.Course overview host')}} *"
                                                    value="">{{__('courses.Course overview host')}}
                                                </option>

                                                <option {{@$course->host=="Youtube"?'selected':''}} value="Youtube">
                                                    {{__('courses.Youtube')}}
                                                </option>

                                                <option value="Vimeo" {{@$course->host=="Vimeo"?'selected':''}}>
                                                    {{__('courses.Vimeo')}}
                                                </option>
                                                @if(moduleStatusCheck("AmazonS3"))
                                                    <option
                                                        value="AmazonS3" {{@$course->host=="AmazonS3"?'selected':''}}>
                                                        {{__('courses.Amazon S3')}}
                                                    </option>
                                                @endif

                                                <option value="Self" {{@$course->host=="Self"?'selected':''}}>
                                                    {{__('courses.Self')}}
                                                </option>


                                            </select>
                                        </div>
                                        <div class="col-xl-8 ">
                                            <div class="input-effect videoUrl"
                                                 style="display:@if((isset($course) && (@$course->host!="Youtube")) || !isset($course)) none  @endif">
                                                <label>{{__('courses.Video URL')}}
                                                    <span>*</span></label>
                                                <input
                                                    id=""
                                                    class="primary_input_field youtubeVideo name{{ $errors->has('trailer_link') ? ' is-invalid' : '' }}"
                                                    type="text" name="trailer_link"
                                                    placeholder="{{__('courses.Video URL')}}"
                                                    autocomplete="off"
                                                    value="" {{$errors->has('trailer_link') ? 'autofocus' : ''}}>
                                                <span class="focus-border"></span>
                                                @if ($errors->has('trailer_link'))
                                                    <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('trailer_link') }}</strong>
                                            </span>
                                                @endif
                                            </div>

                                            <div class="row  vimeoUrl" id=""
                                                 style="display: @if((isset($course) && (@$course->host!="Vimeo")) || !isset($course)) none  @endif">
                                                <div class="col-lg-12" id="">
                                                    <label class="primary_input_label"
                                                           for="">{{__('courses.Vimeo Video')}}</label>
                                                    <select class="primary_select vimeoVideo"
                                                            name="vimeo"
                                                            id="">
                                                        <option
                                                            data-display="{{__('common.Select')}} {{__('courses.Video')}}"
                                                            value="">{{__('common.Select')}} {{__('courses.Video')}}
                                                        </option>
                                                        @foreach ($video_list as $video)
                                                            @if(isset($course))
                                                                <option
                                                                    value="{{@$video['uri']}}" {{$video['uri']==$course->trailer_link?'selected':''}}>{{@$video['name']}}</option>
                                                            @else
                                                                <option
                                                                    value="{{@$video['uri']}}">{{@$video['name']}}</option>
                                                            @endif


                                                        @endforeach
                                                    </select>
                                                    @if ($errors->has('vimeo'))
                                                        <span
                                                            class="invalid-feedback invalid-select"
                                                            role="alert">
                                            <strong>{{ $errors->first('vimeo') }}</strong>
                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="row  videofileupload" id=""
                                                 style="display: @if((isset($course) && ((@$course->host=="Vimeo") ||  (@$course->host=="Youtube")) ) || !isset($course)) none  @endif">

                                                <div class="col-xl-12">
                                                    <div class="primary_input">
                                                        <label class="primary_input_label"
                                                               for="">{{__('courses.Video File')}}</label>
                                                        <div class="primary_file_uploader">
                                                            <input class="primary-input filePlaceholder" type="text"
                                                                   id=" "
                                                                   placeholder="{{__('courses.Browse Video file')}}"
                                                                   readonly="">
                                                            <button class="" type="button">
                                                                <label
                                                                    class="primary-btn small fix-gr-bg"
                                                                    for="document_file_for_add">{{__('common.Browse') }}</label>
                                                                <input type="file" class="d-none fileUpload"
                                                                       name="file"
                                                                       id="document_file_for_add">
                                                            </button>

                                                            @if ($errors->has('file'))
                                                                <span
                                                                    class="invalid-feedback invalid-select"
                                                                    role="alert">
                                            <strong>{{ $errors->first('file') }}</strong>
                                        </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mt-20">
                                        <div class="col-xl-6">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Course Thumbnail') }} *</label>
                                                <div class="primary_file_uploader">
                                                    <input class="primary-input filePlaceholder" type="text"
                                                           id=""
                                                           {{$errors->has('image') ? 'autofocus' : ''}}
                                                           placeholder="{{__('courses.Browse Image file')}}"
                                                           readonly="">
                                                    <button class="" type="button">
                                                        <label class="primary-btn small fix-gr-bg"
                                                               for="document_file_thumb_2">{{__('common.Browse') }}</label>
                                                        <input type="file" class="d-none fileUpload" name="image"
                                                               id="document_file_thumb_2">
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        @if(\Illuminate\Support\Facades\Auth::user()->subscription_api_status==1)
                                            <div class="col-xl-6">
                                                <label class="primary_input_label"
                                                       for="">{{__('newsletter.Subscription List')}}
                                                </label>
                                                <select class="primary_select"
                                                        name="subscription_list" {{$errors->has('subscription_list') ? 'autofocus' : ''}}>
                                                    <option
                                                        data-display="{{__('common.Select')}} {{__('newsletter.Subscription List')}}"
                                                        value="">{{__('common.Select')}} {{__('newsletter.Subscription List')}}

                                                    </option>
                                                    @foreach($sub_lists as $list)
                                                        <option value="{{$list['id']}}">
                                                            {{$list['name']}}
                                                        </option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        @endif
                                    </div>

                                    <div class="row">

                                        <div class="col-xl-12">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Meta keywords') }}</label>
                                                <input class="primary_input_field" name="meta_keywords" placeholder="-"
                                                       id="addMeta"
                                                       type="text" value="{{old('meta_keywords')}}">
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">

                                        <div class="col-xl-12">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Meta description') }}</label>
                                                <textarea id="my-textarea" class="primary_input_field" id
                                                          name="meta_description" style="height: 200px"
                                                          rows="3">{{old('meta_keywords')}}</textarea>
                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-lg-12 text-center pt_15">
                                        <div class="d-flex justify-content-center">
                                            <button class="primary-btn semi_large2  fix-gr-bg" id="save_button_parent"
                                                    type="submit"><i
                                                    class="ti-check"></i> {{__('common.Add') }} {{__('courses.Course') }}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade admin-query" id="editCourse">
                    <div class="modal-dialog modal_1000px modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">{{__('common.Edit')}} {{__('quiz.Topic')}} </h4>
                                <button type="button" class="close " data-dismiss="modal">
                                    <i class="ti-close "></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="{{route('AdminUpdateCourse')}}" method="POST"
                                      enctype="multipart/form-data" id="courseEditForm">
                                    @csrf
                                    <div class="row">
                                        <div class="col-xl-6 ">
                                            <div class="primary_input mb-25">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <label class="primary_input_label"
                                                               for="    "> {{__('courses.Type')}}</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input type="radio"
                                                               class="common-radio type1"
                                                               id="type_edit_1"
                                                               name="type"
                                                               value="1">
                                                        <label
                                                            for="type_edit_1">{{__('courses.Course')}}</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input type="radio"
                                                               class="common-radio type2"
                                                               id="type_edit_2"
                                                               name="type"
                                                               value="2">
                                                        <label
                                                            for="type_edit_2">{{__('quiz.Quiz')}}</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-xl-6 dripCheck">
                                            <div class="primary_input mb-25">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <label class="primary_input_label"
                                                               for="    "> {{__('common.Drip Content')}}</label>
                                                    </div>

                                                    <div class="col-md-6">

                                                        <input type="radio"
                                                               class="common-radio drip0"
                                                               id="drip_edit_0"
                                                               name="drip"
                                                               value="0" {{@$course->drip==0?"checked":""}}>
                                                        <label
                                                            for="drip_edit_0">{{__('common.No')}}</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input type="radio"
                                                               class="common-radio drip1"
                                                               id="drip_edit_1"
                                                               name="drip"
                                                               value="1" {{@$course->drip==1?"checked":""}}>
                                                        <label
                                                            for="drip_edit_1">{{__('common.Yes')}}</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="title">{{__('quiz.Topic')}} {{__('common.Title')}}
                                                    *</label>
                                                <input class="primary_input_field" name="title"
                                                       id="title"
                                                       placeholder="-"
                                                       type="text" {{$errors->has('title') ? 'autofocus' : ''}}>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="id" class="course_id" id="editCourseId"
                                           value="">

                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="about">{{__('courses.Course')}} {{__('courses.Requirements')}} </label>
                                                <textarea class="lms_summernote"
                                                          name="requirements"

                                                          id="requirementsEdit" cols="30"
                                                          rows="10"> </textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="about">{{__('courses.Course')}} {{__('courses.Description')}}</label>
                                                <textarea class="lms_summernote" name="about"

                                                          id="aboutEdit" cols="30"
                                                          rows="10"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="about">{{__('courses.Course')}} {{__('courses.Outcomes')}}  </label>
                                                <textarea class="lms_summernote" name="outcomes"

                                                          id="outcomesEdit" cols="30"
                                                          rows="10"> </textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-xl-6 courseBox">
                                            <select class="primary_select edit_category_id"
                                                    name="category"
                                                {{$errors->has('category') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{__('common.Select')}} {{__('quiz.Category')}}"
                                                    value="">{{__('common.Select')}} {{__('quiz.Category')}}
                                                    *
                                                </option>
                                                @foreach($categories as $category)
                                                    <option value="{{$category->id}}">{{@$category->name}} </option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="col-xl-6 courseBox"
                                             id="edit_subCategoryDiv{{@$course->id}}">
                                            <select class="primary_select " name="sub_category"
                                                    id="edit_subcategory_id" {{$errors->has('sub_category') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{__('common.Select')}} {{__('courses.Sub Category')}}"
                                                    value="">{{__('common.Select')}} {{__('courses.Sub Category')}}

                                                </option>


                                            </select>
                                        </div>
                                        <div class="col-xl-6 mt-30 quizBox"
                                             style="display: none">
                                            <select class="primary_select" name="quiz"
                                                    id="quiz_edit_id" {{$errors->has('quiz') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{__('common.Select')}} {{__('quiz.Quiz')}}"
                                                    value="">{{__('common.Select')}} {{__('quiz.Quiz')}}
                                                    *
                                                </option>
                                                @foreach($quizzes as $quiz)
                                                    <option value="{{$quiz->id}}"
                                                    >{{@$quiz->title}} </option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="col-xl-4 mt-30 makeResize">
                                            <select class="primary_select" id="levelEdit"
                                                    name="level" {{$errors->has('level') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{__('common.Select')}} {{__('courses.Level')}}"
                                                    value="">{{__('common.Select')}} {{__('courses.Level')}}
                                                    *
                                                </option>
                                                @foreach($levels as $level)
                                                    <option value="{{$level->id}}"
                                                    >
                                                        {{$level->title}}
                                                    </option>
                                                @endforeach

                                            </select>
                                        </div>
                                        <div class="col-xl-4 mt-30 makeResize" id="">
                                            <select class="primary_select mb_30" name="language"
                                                    id="languageEdit" {{$errors->has('language') ? 'autofocus' : ''}}>
                                                <option
                                                    data-display="{{__('common.Select')}} {{__('courses.Language')}}"
                                                    value="">{{__('common.Select')}} {{__('courses.Language')}}
                                                    *
                                                </option>

                                                @foreach ($languages as $language)
                                                    <option value="{{$language->id}}"
                                                    >{{$language->native}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-xl-4 makeResize">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('common.Duration')}}
                                                    *</label>
                                                <input class="primary_input_field" id="durationEdit"
                                                       name="duration" placeholder="-"

                                                       type="text" {{$errors->has('duration') ? 'autofocus' : ''}}>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row d-none">
                                        <div class="col-lg-6">
                                            <div
                                                class="checkbox_wrap d-flex align-items-center">
                                                <label for="course_1" class="switch_toggle">
                                                    <input type="checkbox" id="edit_course_1">
                                                    <i class="slider round"></i>
                                                </label>
                                                <label>{{__('courses.This course is a top course')}}</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-20">
                                        <div class="col-lg-6">
                                            <div
                                                class="checkbox_wrap d-flex align-items-center mt-40">
                                                <label for="editCourseFree"
                                                       class="switch_toggle">
                                                    <input type="checkbox" class="edit_course_2" name="is_free"
                                                           value="1"
                                                           id="editCourseFree"
                                                    >
                                                    <i class="slider round"></i>
                                                </label>
                                                <label>{{__('courses.This course is a free course')}}</label>
                                            </div>
                                        </div>
                                        <div class="col-xl-4"
                                             id="edit_price_div">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Price')}}</label>
                                                <input class="primary_input_field" name="price" id="priceEdit"
                                                       placeholder="-"
                                                       value="" type="text">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-20 editDiscountDiv">
                                        <div class="col-lg-6">
                                            <div
                                                class="checkbox_wrap d-flex align-items-center mt-40">
                                                <label for="editCourseDiscount"
                                                       class="switch_toggle">
                                                    <input type="checkbox" class="edit_course_3"
                                                           name="is_discount" value="1"
                                                           id="editCourseDiscount">
                                                    <i class="slider round"></i>
                                                </label>
                                                <label>{{__('courses.This course has discounted price')}}</label>
                                            </div>
                                        </div>

                                        <div class="col-xl-4"
                                             id="edit_discount_price_div "
                                        >
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Discount')}} {{__('courses.Price')}}</label>
                                                <input class="primary_input_field editDiscount"
                                                       name="discount_price" id="editDiscountPrice"

                                                       placeholder="-" type="text">
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row mt-20 videoOption">
                                        <div class="col-xl-4 mt-25">
                                            <select class="primary_select category_id "
                                                    name="host"
                                                    id="editCourseHost">
                                                <option
                                                    data-display="{{__('courses.Course overview host')}} *"
                                                    value="">{{__('courses.Course overview host')}}
                                                </option>

                                                <option value="Youtube"
                                                >
                                                    {{__('courses.Youtube')}}
                                                </option>
                                                <option value="Vimeo"
                                                >
                                                    {{__('courses.Vimeo')}}
                                                </option>
                                                @if(moduleStatusCheck("AmazonS3"))
                                                    <option value="AmazonS3"
                                                    >
                                                        {{__('courses.Amazon S3')}}
                                                    </option>
                                                @endif

                                                <option value="Self"
                                                >
                                                    {{__('courses.Self')}}
                                                </option>


                                            </select>
                                        </div>
                                        <div class="col-xl-8 ">
                                            <div class="input-effect videoUrl"
                                                 style="display:@if((isset($course) && (@$course->host!="Youtube")) || !isset($course)) none  @endif">
                                                <label>{{__('courses.Video URL')}}
                                                    <span>*</span></label>
                                                <input
                                                    id="couseEditViewUrl"
                                                    class="primary_input_field youtubeVideo name{{ $errors->has('trailer_link') ? ' is-invalid' : '' }}"
                                                    type="text" name="trailer_link"
                                                    placeholder="{{__('courses.Video URL')}}"
                                                    autocomplete="off"
                                                    value=" " {{$errors->has('trailer_link') ? 'autofocus' : ''}}>
                                                <span class="focus-border"></span>
                                                @if ($errors->has('trailer_link'))
                                                    <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('trailer_link') }}</strong>
                                            </span>
                                                @endif
                                            </div>

                                            <div class="row  vimeoUrl" id=""
                                                 style="display: @if((isset($course) && (@$course->host!="Vimeo")) || !isset($course)) none  @endif">
                                                <div class="col-lg-12" id="">
                                                    <label class="primary_input_label"
                                                           for="">{{__('courses.Vimeo Video')}}</label>
                                                    <select class="primary_select vimeoVideo"
                                                            name="vimeo"
                                                            id="viemoEditCourse">
                                                        <option
                                                            data-display="{{__('common.Select')}} {{__('courses.Video')}}"
                                                            value="">{{__('common.Select')}} {{__('courses.Video')}}
                                                        </option>
                                                        @foreach ($video_list as $video)
                                                            <option
                                                                value="{{@$video['uri']}}">{{@$video['name']}}</option>


                                                        @endforeach
                                                    </select>
                                                    @if ($errors->has('vimeo'))
                                                        <span
                                                            class="invalid-feedback invalid-select"
                                                            role="alert">
                                            <strong>{{ $errors->first('vimeo') }}</strong>
                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="row  videofileupload" id=""
                                                 style="display: @if((isset($course) && ((@$course->host=="Vimeo") ||  (@$course->host=="Youtube")) ) || !isset($course)) none  @endif">

                                                <div class="col-xl-12">
                                                    <div class="primary_input">
                                                        <label class="primary_input_label"
                                                               for="">{{__('courses.Video File')}}</label>
                                                        <div class="primary_file_uploader">
                                                            <input
                                                                class="primary-input filePlaceholder"
                                                                type="text"

                                                                placeholder="{{__('courses.Browse Video file')}}"
                                                                readonly="">
                                                            <button class="" type="button">
                                                                <label
                                                                    class="primary-btn small fix-gr-bg"
                                                                    for="document_file_edit">{{__('common.Browse') }}</label>
                                                                <input type="file"
                                                                       class="d-none fileUpload"
                                                                       name="file"
                                                                       id="document_file_edit">
                                                            </button>

                                                            @if ($errors->has('file'))
                                                                <span
                                                                    class="invalid-feedback invalid-select"
                                                                    role="alert">
                                            <strong>{{ $errors->first('file') }}</strong>
                                        </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mt-20">


                                        <div class="col-xl-6">
                                            <div class="primary_input mb-35">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Course Thumbnail')}}
                                                    *</label>
                                                <div class="primary_file_uploader">
                                                    <input class="primary-input filePlaceholder"
                                                           type="text"
                                                           id=""

                                                           placeholder="{{__('courses.Browse Image file')}}"
                                                           readonly="" {{$errors->has('image') ? 'autofocus' : ''}}>
                                                    <button class="" type="button">
                                                        <label
                                                            class="primary-btn small fix-gr-bg"
                                                            for="document_file_1_edit_">{{__('common.Browse')}}</label>
                                                        <input type="file"
                                                               class="d-none fileUpload"
                                                               name="image"
                                                               id="document_file_1_edit_">
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        @if(\Illuminate\Support\Facades\Auth::user()->subscription_api_status==1)
                                            <div class="col-xl-6">
                                                <label class="primary_input_label"
                                                       for="">{{__('newsletter.Subscription List')}}
                                                </label>
                                                <select class="primary_select" id="subscriptionEdit"
                                                        name="subscription_list" {{$errors->has('subscription_list') ? 'autofocus' : ''}}>
                                                    <option
                                                        data-display="{{__('common.Select')}} {{__('newsletter.Subscription List')}}"
                                                        value="">{{__('common.Select')}} {{__('newsletter.Subscription List')}}

                                                    </option>
                                                    @foreach($sub_lists as $list)
                                                        <option value="{{$list['id']}}">
                                                            {{$list['name']}}
                                                        </option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="row">


                                        <div class="col-xl-12">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Meta keywords')}}</label>
                                                <input class="primary_input_field"
                                                       name="meta_keywords" id="editMetaKey"
                                                       placeholder="-" type="text">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="primary_input mb-25">
                                                <label class="primary_input_label"
                                                       for="">{{__('courses.Meta description')}}</label>
                                                <textarea id="editMetaDetails"
                                                          class="primary_input_field"
                                                          name="meta_description"
                                                          style="height: 200px"
                                                          rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-center pt_15">
                                        <div class="d-flex justify-content-center">
                                            <button class="primary-btn semi_large2  fix-gr-bg"
                                                    id="save_button_parent" type="submit"><i
                                                    class="ti-check"></i> {{__('common.Update')}}  {{__('courses.Course')}}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>


        </div>
    </section>
    @include('backend.partials.delete_modal')
@endsection
@push('scripts')
    @if ($errors->any())
        <script>
            @if(Session::has('type'))
            @if(Session::get('type')=="store")
            $('#add_course').modal('show');
            @else

            @endif
            @endif
        </script>
    @endif
    <script src="{{asset('/')}}/Modules/CourseSetting/Resources/assets/js/course.js"></script>

    @php

        if (\Route::current()->getName() == 'getAllCourse') {
            $url = route('getAllCourseData').'?status=3';
        }  elseif (\Route::current()->getName() == 'getActiveCourse') {
            $url = route('getAllCourseData').'?status=1';
        } elseif (\Route::current()->getName() == 'getPendingCourse') {
            $url = route('getAllCourseData').'?status=0';
        } elseif (\Route::current()->getName() == 'courseSortBy' ||\Route::current()->getName() == 'courseSortByGet') {

    $category=request()->get('category');
    $type=request()->get('type');
    $instructor=request()->get('instructor');
    $status=request()->get('search_status');
    $url = route('getAllCourseData').'?search_status='.$status.'&category='.$category.'&type='.$type.'&instructor='.$instructor;

        }else{
             $url = route('getAllCourseData');
        }

    @endphp

    <script>
        let table = $('.classList').DataTable({
            bLengthChange: false,
            "bDestroy": true,
            processing: true,
            serverSide: true,
            ajax: '{!! $url !!}',
            columns: [
                {data: 'type', name: 'type'},
                {data: 'title', name: 'title'},
                {data: 'category.name', name: 'category.name'},
                {data: 'quiz.title', name: 'quiz.title'},
                {data: 'user.name', name: 'user.name'},
                {data: 'status', name: 'status'},
                {data: 'lessons', name: 'lessons'},
                {data: 'total_enrolled', name: 'total_enrolled'},
                {data: 'price', name: 'price'},
                {data: 'action', name: 'action'},

            ],
            language: {
                emptyTable: "No data available in the table",
                search: "<i class='ti-search'></i>",
                searchPlaceholder: 'Quick Search',
                paginate: {
                    next: "<i class='ti-arrow-right'></i>",
                    previous: "<i class='ti-arrow-left'></i>"
                }
            },
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="far fa-copy"></i>',
                    title: $("#logo_title").val(),
                    titleAttr: 'Copy',
                    exportOptions: {
                        columns: ':visible',
                        columns: ':not(:last-child)',
                    }
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="far fa-file-excel"></i>',
                    titleAttr: 'Excel',
                    title: $("#logo_title").val(),
                    margin: [10, 10, 10, 0],
                    exportOptions: {
                        columns: ':visible',
                        columns: ':not(:last-child)',
                    },

                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="far fa-file-alt"></i>',
                    titleAttr: 'CSV',
                    exportOptions: {
                        columns: ':visible',
                        columns: ':not(:last-child)',
                    }
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="far fa-file-pdf"></i>',
                    title: $("#logo_title").val(),
                    titleAttr: 'PDF',
                    exportOptions: {
                        columns: ':visible',
                        columns: ':not(:last-child)',
                    },
                    orientation: 'landscape',
                    pageSize: 'A4',
                    margin: [0, 0, 0, 12],
                    alignment: 'center',
                    header: true,
                    customize: function (doc) {
                        doc.content[0].table.widths =
                            Array(doc.content[0].table.body[0].length + 1).join('*').split('');
                    }

                },
                {
                    extend: 'print',
                    text: '<i class="fa fa-print"></i>',
                    titleAttr: 'Print',
                    title: $("#logo_title").val(),
                    exportOptions: {
                        columns: ':not(:last-child)',
                    }
                },
                {
                    extend: 'colvis',
                    text: '<i class="fa fa-columns"></i>',
                    postfixButtons: ['colvisRestore']
                }
            ],
            columnDefs: [{
                visible: false
            }],
            responsive: true,
        });

        $('.classList').on('click', '.editCourseLink ', function () {
            let id = $(this).data('id');
            let category_id = $(this).data('category_id');
            let subcategory_id = $(this).data('subcategory_id');
            let quiz_id = $(this).data('quiz_id');
            let class_id = $(this).data('class_id');
            let user_id = $(this).data('user_id');
            let lang_id = $(this).data('lang_id');
            let title =$(this).data("title");
            let slug = $(this).data('slug');
            let duration = $(this).data('duration');
            let image = $(this).data('image');
            let thumbnail = $(this).data('thumbnail');
            let price = $(this).data('price');
            let discount_price = $(this).data('discount_price');
            let publish = $(this).data('publish');
            let status = $(this).data('status');
            let level = $(this).data('level');
            let trailer_link = $(this).data('trailer_link');
            let host = $(this).data('host');

            let about = $(this).data('about');
            let special_commission = $(this).data('special_commission');
            let total_enrolled = $(this).data('total_enrolled');
            let reveune = $(this).data('reveune');
            let reveiw = $(this).data('reveiw');
            let type = $(this).data('type');
            let created_at = $(this).data('created_at');
            let updated_at = $(this).data('updated_at');
            let drip = $(this).data('drip');
            let subscription = $(this).data('subscription');
            let requirements = $(this).data('requirements');
            let outcomes = $(this).data('outcomes');
            let subscription_list = $(this).data('subscription_list');

            console.log(drip);
            if (type == 1) {
                $('#type_edit_1').prop('checked', true);
                $('#type_edit_2').attr('checked', false);
            } else {
                $('#type_edit_1').attr('checked', false);
                $('#type_edit_2').attr('checked', true);

            }

            if (drip == 0) {
                $('#drip_edit_0').attr('checked', true);
                $('#drip_edit_1').attr('checked', false);

            } else {
                $('#drip_edit_0').attr('checked', false);
                $('#drip_edit_1').attr('checked', true);
            }
            $('#title').val(title);

            $('#requirementsEdit').summernote('code', requirements);
            $('#aboutEdit').summernote('code', about);
            $('#outcomesEdit').summernote('code', outcomes);


            $('.edit_category_id').val(category_id);
            $('.edit_category_id').trigger('change');
            $('.edit_category_id').niceSelect('update');

            $('#quiz_edit_id').val(quiz_id);
            $('#quiz_edit_id').trigger('change');
            $('#quiz_edit_id').niceSelect('update');


            $('#levelEdit').val(level);
            $('#levelEdit').trigger('change');
            $('#levelEdit').niceSelect('update');

            $('#durationEdit').val(duration);

            $('#languageEdit').val(lang_id);
            $('#languageEdit').trigger('change');
            $('#languageEdit').niceSelect('update');


            let child = $('#edit_subcategory_id');

            $.ajax({
                url: '{{url('admin/course/ajaxGetCourseSubCategory')}}?id=' + category_id,
                type: 'GET',
                dataType: 'json'
            })
                .done(function (data) {
                    child.empty();
                    $.each(data[0], function (i, v) {

                        child.append(
                            $('<option>', {
                                value: v.id,
                                text: v.name
                            })
                        );
                    })
                    child.trigger('change');
                    child.niceSelect('update');

                })
                .fail(function (data) {
                    toastr.error('Something Wrong!', 'Error')
                });

            $('#edit_subcategory_id').val(subcategory_id);

            if (price == 0) {
                $('#editCourseFree').attr('checked', true);
            }

            $('#edit_subcategory_id').val(subcategory_id);
            $('#priceEdit').val(price);


            if (discount_price == 0) {
                $('#editCourseDiscount').attr('checked', true);
            }
            $('#editDiscountPrice').val(discount_price);


            $('#editCourseHost').val(host);
            $('#editCourseHost').trigger('change');
            $('#editCourseHost').niceSelect('update');


            $('#couseEditViewUrl').val(trailer_link);

            $('#viemoEditCourse').val(trailer_link);
            $('#viemoEditCourse').trigger('change');
            $('#viemoEditCourse').niceSelect('update');


            $('#subscriptionEdit').val(subscription);
            $('#subscriptionEdit').trigger('change');
            $('#subscriptionEdit').niceSelect('update');
            console.log($(this));

            let meta_keywords = $(this).data('metakeyword');
            let meta_description = $(this).data('metadescription');
            $('#editMetaKey').val(meta_keywords);
            $('#editCourseId').val(id);
            $('#editMetaDetails').html(meta_description);

        });


    </script>
@endpush
